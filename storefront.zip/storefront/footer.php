</main>

<footer>
  <div class="footer-info">
    <h2></h2>
  </div>
</footer>

<script src="./static/js/utils.js"></script>
</body>

</html>
